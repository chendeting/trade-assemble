


var citypicker='<div class="letter" style="display: none">' +
' <ul>' +
'<li><a href="javascript:;">A</a></li>' +
'<li><a href="javascript:;">B</a></li>' +
'<li><a href="javascript:;">C</a></li>' +
'<li><a href="javascript:;">D</a></li>' +
'<li><a href="javascript:;">E</a></li>' +
'<li><a href="javascript:;">F</a></li>' +
'<li><a href="javascript:;">G</a></li>' +
'<li><a href="javascript:;">H</a></li>' +
'<li><a href="javascript:;">J</a></li>' +
'<li><a href="javascript:;">K</a></li> ' +
'<li><a href="javascript:;">L</a></li> ' +
'<li><a href="javascript:;">M</a></li> ' +
'<li><a href="javascript:;">N</a></li> ' +
'<li><a href="javascript:;">P</a></li> ' +
'<li><a href="javascript:;">Q</a></li> ' +
'<li><a href="javascript:;">R</a></li> ' +
'<li><a href="javascript:;">S</a></li> ' +
'<li><a href="javascript:;">T</a></li> ' +
'<li><a href="javascript:;">W</a></li>' +
' <li><a href="javascript:;">X</a></li> ' +
'<li><a href="javascript:;">Y</a></li> ' +
'<li><a href="javascript:;">Z</a></li>'+
'</ul>'+
'</div>';






