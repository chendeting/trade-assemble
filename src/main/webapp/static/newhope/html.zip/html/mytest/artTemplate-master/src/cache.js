var cacheStore = template.cache = {};


